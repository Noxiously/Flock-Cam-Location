import "./globals.css";

export const metadata = {
  title: "Flock Map Tracker",
  description: "Interactive map of verified Flock cameras",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
