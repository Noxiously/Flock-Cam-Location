"use client";

import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

// Fix leaflet's default icon paths (use CDN)
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

// Preloaded verified cameras
const verifiedCameras = [
  {
    id: "seed-1151",
    lat: 39.944868,
    lng: -82.957732,
    address: "1151 College Ave, Columbus, OH 43209",
  },
  {
    id: "seed-1",
    lat: 39.948333,
    lng: -82.937222,
    address: "39°56\'54.0\"N 82°56\'14.0\"W",
  },
  {
    id: "seed-2",
    lat: 39.944972,
    lng: -82.935222,
    address: "39°56\'41.9\"N 82°56\'06.8\"W",
  },
  {
    id: "seed-3",
    lat: 39.944556,
    lng: -82.934972,
    address: "39°56\'40.4\"N 82°56\'05.9\"W",
  },
];

// Auto center component
function FitBounds({ cameras }) {
  const map = useMap();
  useEffect(() => {
    if (!map) return;
    if (!cameras || cameras.length === 0) return;
    const group = new L.FeatureGroup(cameras.map(c => L.marker([c.lat, c.lng])));
    map.fitBounds(group.getBounds().pad(0.2));
  }, [map, cameras]);
  return null;
}

export default function FlockMap() {
  const [userPos, setUserPos] = useState(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        p => setUserPos([p.coords.latitude, p.coords.longitude]),
        () => setUserPos([verifiedCameras[0].lat, verifiedCameras[0].lng])
      );
    } else {
      setUserPos([verifiedCameras[0].lat, verifiedCameras[0].lng]);
    }
  }, []);

  return (
    <MapContainer
      center={userPos || [verifiedCameras[0].lat, verifiedCameras[0].lng]}
      zoom={13}
      style={{ height: "100%", width: "100%" }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      <FitBounds cameras={verifiedCameras} />

      {verifiedCameras.map(cam => (
        <Marker key={cam.id} position={[Number(cam.lat), Number(cam.lng)]}>
          <Popup>
            <strong>Verified Flock Camera</strong><br />
            {cam.address}
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
