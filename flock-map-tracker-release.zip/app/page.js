"use client";

import dynamic from "next/dynamic";

const FlockMap = dynamic(() => import("./components/FlockMap"), {
  ssr: false,
  loading: () => <p style={{padding:16}}>Loading map…</p>,
});

export default function Page() {
  return (
    <main>
      <header style={{padding:16, background:'#fff', boxShadow:'0 1px 4px rgba(0,0,0,0.06)'}}>
        <h1 style={{margin:0}}>Flock Map Tracker</h1>
      </header>
      <div style={{height:'calc(100vh - 64px)'}}>
        <FlockMap />
      </div>
    </main>
  );
}
