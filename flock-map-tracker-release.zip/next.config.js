/** next config */
module.exports = { reactStrictMode: true };
