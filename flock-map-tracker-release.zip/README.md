# Flock Map Tracker (Release ZIP)

This is a minimal Next.js (App Router) project with React-Leaflet (OpenStreetMap) and four preloaded verified camera markers.
It is packaged to run on Replit or locally.

## Quick start

1. Install dependencies:
   ```
   npm install
   ```

2. Run development server:
   ```
   npm run dev
   ```

3. Open the preview (Replit opens automatically) or visit http://localhost:3000

## Files of interest
- `app/page.js` - main page that loads the map
- `app/components/FlockMap.js` - map component with preloaded verified markers
- `.env.local.example` - placeholders for Firebase keys (optional)

To integrate Firebase later, copy `.env.local.example` to `.env.local` and add your Firebase config values or set them in Replit Secrets.
