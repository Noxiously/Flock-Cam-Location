# Web Admin - Flock Map Tracker

Run:
```
cd web-admin
npm install
npm run dev
```

Set environment variables (NEXT_PUBLIC_...) via Replit Secrets or .env.local.
