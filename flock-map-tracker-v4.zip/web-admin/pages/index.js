
import Head from 'next/head'
import { useEffect, useState, useRef } from 'react'
import { initializeApp } from 'firebase/app'
import { getFirestore, collection, addDoc, serverTimestamp, onSnapshot, query, orderBy } from 'firebase/firestore'
import { getAuth, signInWithPopup, GoogleAuthProvider } from 'firebase/auth'
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet'
import L from 'leaflet'

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID
};

let app
try { app = initializeApp(firebaseConfig) } catch(e) {}

const defaultCenter = [39.9612, -82.9988] // Columbus, OH

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: '/marker-icon-2x.png',
  iconUrl: '/marker-icon.png',
  shadowUrl: '/marker-shadow.png'
});

// helper component to center map on user
function Locate({ setUserPos }) {
  const map = useMap();
  useEffect(() => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition((pos) => {
      const { latitude, longitude } = pos.coords;
      map.setView([latitude, longitude], 14);
      setUserPos([latitude, longitude]);
    }, () => {
      map.setView(defaultCenter, 13);
    }, { enableHighAccuracy: true, timeout: 5000 });
  }, [map]);
  return null;
}

export default function Home() {
  const [user, setUser] = useState(null);
  const [cameras, setCameras] = useState([]);
  const [adding, setAdding] = useState(false);
  const [addPos, setAddPos] = useState(null);
  const db = getFirestore();
  const auth = getAuth();

  useEffect(() => {
    const q = query(collection(db, 'flockCameras'), orderBy('timestamp', 'desc'));
    const unsub = onSnapshot(q, snap => {
      const arr = [];
      snap.forEach(d => arr.push({ id: d.id, ...d.data() }));
      setCameras(arr);
    });
    return () => unsub();
  }, []);

  async function signIn() {
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
    setUser(auth.currentUser);
  }

  async function startAdd() {
    setAdding(true);
    // center pos will be set by user location or map center - simple approach: use browser geolocation
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
        setAddPos({ lat: pos.coords.latitude, lng: pos.coords.longitude });
      }, () => {
        setAddPos({ lat: defaultCenter[0], lng: defaultCenter[1] });
      });
    } else {
      setAddPos({ lat: defaultCenter[0], lng: defaultCenter[1] });
    }
  }

  async function submitAdd(note='') {
    if (!addPos) return alert('No position set');
    await addDoc(collection(db, 'cameraReports'), {
      lat: addPos.lat,
      lng: addPos.lng,
      note,
      approxRadius: 50,
      region: '', // client can optionally set region
      createdAt: serverTimestamp(),
      reporter: user ? { uid: user.uid, name: user.displayName } : null,
      verified: false
    });
    setAdding(false);
    alert('Report submitted (unverified).');
  }

  return (
    <div className="h-screen bg-gray-100">
      <Head><title>Flock Map Tracker</title></Head>
      <header className="p-4 bg-white shadow flex justify-between items-center">
        <h1 className="text-xl font-bold">Flock Map Tracker</h1>
        <div>
          {user ? <span className="mr-3">{user.displayName}</span> : <button onClick={signIn} className="px-3 py-1 bg-blue-600 text-white rounded">Sign in</button>}
          <button onClick={startAdd} className="ml-2 px-3 py-1 bg-green-600 text-white rounded">+ Add Camera</button>
        </div>
      </header>

      <main className="h-[calc(100vh-64px)]">
        <MapContainer center={defaultCenter} zoom={13} className="h-full">
          <Locate setUserPos={() => {}} />
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="© OpenStreetMap contributors" />
          {cameras.map(c => (
            <Marker key={c.id} position={[c.coordinates?.lat || c.lat, c.coordinates?.lng || c.lng]}>
              <Popup>
                <div>
                  <h3 className="font-bold">{c.title || 'Camera'}</h3>
                  <p>{c.address || c.note}</p>
                  <p className="text-sm text-gray-500">{c.verified ? 'Verified' : 'Unverified'}</p>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </main>

      {adding && (
        <div className="fixed bottom-6 right-6 bg-white p-4 rounded shadow">
          <p className="mb-2">Adding camera at approx: {addPos ? `${addPos.lat.toFixed(5)}, ${addPos.lng.toFixed(5)}` : '—'}</p>
          <button onClick={() => submitAdd('User reported camera')} className="px-3 py-1 bg-blue-600 text-white rounded">Submit</button>
          <button onClick={() => setAdding(false)} className="ml-2 px-3 py-1 bg-gray-300 rounded">Cancel</button>
        </div>
      )}
    </div>
)
}
