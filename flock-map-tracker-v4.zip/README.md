# Flock Map Tracker (v4)

Interactive map app (web admin) showing Flock camera locations.
Features:
- OpenStreetMap + React-Leaflet map
- Auto-center on user's location (with fallback to Columbus, OH)
- One admin-verified seeded camera (1151 College Ave, Columbus OH)
- Add Camera button for signed-in users (saves unverified reports)
- Firebase Auth (Google), Firestore, Cloud Functions (FCM), admin callable functions
- Replit-ready and GitHub Actions workflow for auto-deploy

See web-admin/README.md and functions/README.md for workspace-specific details.
