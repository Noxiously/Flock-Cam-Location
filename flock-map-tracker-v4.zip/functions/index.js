const functions = require('firebase-functions');
const admin = require('firebase-admin');

admin.initializeApp();
const db = admin.firestore();

function getAdminUids() {
  const conf = functions.config && functions.config().admin;
  if (conf && conf.uids) return conf.uids.split(',').map(s => s.trim()).filter(Boolean);
  if (process.env.ADMIN_UIDS) return process.env.ADMIN_UIDS.split(',').map(s => s.trim()).filter(Boolean);
  return [];
}
function isAdmin(uid) { return getAdminUids().includes(uid); }

exports.notifyOnNewReport = functions.firestore
  .document('cameraReports/{reportId}')
  .onCreate(async (snap, context) => {
    const data = snap.data();
    const title = 'New Camera Report';
    const shortNote = (data.note && data.note.length > 120) ? data.note.slice(0,117)+'...' : (data.note || '');
    const body = shortNote || `Reported near (${Number(data.lat).toFixed(4)}, ${Number(data.lng).toFixed(4)})`;

    const messages = [{ notification:{title, body}, data:{id:context.params.reportId, lat:String(data.lat), lng:String(data.lng)}, topic:'newReports' }];

    if (data.region) {
      messages.push({ notification:{title, body}, data:{id:context.params.reportId, lat:String(data.lat), lng:String(data.lng), region:String(data.region)}, topic:`region_${data.region}`});
    }

    for (const msg of messages) {
      try {
        const res = await admin.messaging().send(msg);
        console.log('Sent to', msg.topic, res);
      } catch (err) {
        console.error('FCM send error', err);
      }
    }
    return null;
  });

exports.subscribeTokenToTopic = functions.https.onCall(async (data, context) => {
  const token = data.token; const topic = data.topic || 'newReports';
  if (!token) throw new functions.https.HttpsError('invalid-argument','Missing token');
  try { const resp = await admin.messaging().subscribeToTopic(token, topic); return { success:true, resp }; }
  catch (err) { throw new functions.https.HttpsError('internal','Failed to subscribe token'); }
});

exports.adminToggleVerify = functions.https.onCall(async (data, context) => {
  if (!context.auth || !context.auth.uid) throw new functions.https.HttpsError('unauthenticated','No auth');
  if (!isAdmin(context.auth.uid)) throw new functions.https.HttpsError('permission-denied','Not admin');
  const reportId = data.reportId; if (!reportId) throw new functions.https.HttpsError('invalid-argument','Missing reportId');
  const docRef = db.collection('cameraReports').doc(reportId);
  const snap = await docRef.get(); if (!snap.exists) throw new functions.https.HttpsError('not-found','Not found');
  const current = snap.data();
  await docRef.update({ verified: !current.verified });
  return { success:true, verified: !current.verified };
});

exports.adminDeleteReport = functions.https.onCall(async (data, context) => {
  if (!context.auth || !context.auth.uid) throw new functions.https.HttpsError('unauthenticated','No auth');
  if (!isAdmin(context.auth.uid)) throw new functions.https.HttpsError('permission-denied','Not admin');
  const reportId = data.reportId; if (!reportId) throw new functions.https.HttpsError('invalid-argument','Missing reportId');
  await db.collection('cameraReports').doc(reportId).delete();
  return { success:true };
});
