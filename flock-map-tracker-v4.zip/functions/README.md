Run `node seed/initialData.js` after installing dependencies to seed the verified camera.
