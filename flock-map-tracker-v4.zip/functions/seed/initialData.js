const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

async function seed() {
  const docRef = db.collection('flockCameras').doc('seed_college_001');
  await docRef.set({
    title: "Flock Camera - College Ave",
    description: "Verified Flock camera installed near College Ave and E Livingston Ave.",
    coordinates: { lat: 39.9441, lng: -82.9589 },
    address: "1151 College Ave, Columbus, OH 43209",
    region: "OH",
    verified: true,
    addedBy: "admin",
    timestamp: admin.firestore.FieldValue.serverTimestamp()
  });
  console.log("Seed complete");
  process.exit(0);
}
seed().catch(console.error);
